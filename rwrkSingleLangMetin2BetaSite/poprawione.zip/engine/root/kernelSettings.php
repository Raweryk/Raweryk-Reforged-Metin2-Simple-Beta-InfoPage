<?php
	$debugKey = "QA7b2yoKrqQbCesL9gFA";			//	Twój unikalny klucz debugujący
	$stringKey = "T6yBQj9z5eKuqtUCASeG";		//	Klucz wyświetlający frazy językowe

	$rwrkIndex = "index.php";								//
	$rwrkRegister = "register.php";					//
	$rwrkDownload = "download.php";					//
	$debugMode = 0;													//
	$disablePreloader = 0;									//
	$displayLangStrings = 0;								//
	$forceCrash = 0;												//
	$offlineTimeout = 600;									//
	$errorTimeout = 300;										//
	$websiteTimeout = 900;									//

/*	$boot = "<meta http-equiv='refresh' content='$websiteTimeout'/>
	<link rel='stylesheet' href='engine/frontend/index.css'/>
	<title>".<?php if ($overwriteTitle == 1) { echo "$sysSiteTitle"; } else { echo "$coreServerHello $coreServerName"; } ?></title>"*/
?>
