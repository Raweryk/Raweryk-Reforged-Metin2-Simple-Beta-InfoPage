<!DOCTYPE html>
<html lang="pl">
	<head>
		<?php require('../config.rwrk');?>
		<meta charset="pl-PL.UTF-8">
		<meta http-equiv='refresh' content='<?php echo "$offlineTimeout"; ?>;url=../../'/>
		<link rel="icon" type="image/jpg" href="raweryk.jpg"/>
		<link rel="stylesheet" href="root.css">
		<title>Offline</title>
	</head>
	<body>
		<span class="rwrkError_Title">Raweryk</span>
		<span class="rwrkError_Desc">Strona aktualnie jest wyłączona</span>
		<ul>
			<li>test1</li>
			<li>test2</li>
		</ul>
		<span class="rwrkError_Link"><a href="../../">Wciśnij tutaj, by powrócić<span class="rwrkError_Blink">_</span></a></span>
	</body>
</html>
