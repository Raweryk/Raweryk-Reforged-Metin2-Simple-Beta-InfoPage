<?php
//	SYS LEVEL
	$sysSiteTitle = "sysSiteTitle";
	$sysNavIndex = "sysNavIndex";
	$sysNavRegister = "sysNavRegister";
	$sysNavDownload = "sysNavDownload";
	$sysServerHello ="sysServerHello";
	$sysServerDesc ="sysServerDesc";
	$sysNavSeparate = "sysNavSeparate";

//	CORE LEVEL
	$coreServerName = "coreServerName";
	$coreServerHello = "coreServerHello";
	$coreServerDesc = "coreServerDesc"; //DEL
	$coreButtonDesc = "coreButtonDesc";
	$coreAssist = "coreAssist";
	$coreAssistLink= "coreAssistLink";


//	USER LEVEL
	$userServerName = "userServerName"; //DEL
	$userNavBoard = "userNavBoard";
	$userNavDiscord = "userNavDiscord";
	$userNavFacebook = "userNavFacebook";

//	URI LEVEL
	$uriButtonURI = "#uriButtonURI";

	$uriBoardURI = "#uriBoardURI";
	$uriDiscordURI = "#uriDiscordURI";
	$uriFacebookURI = "#uriFacebookURI";
	$uriDownloadURI = "#uriDownloadURI";
?>