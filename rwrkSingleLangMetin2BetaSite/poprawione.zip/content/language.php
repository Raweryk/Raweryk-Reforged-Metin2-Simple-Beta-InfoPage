<?php
//	SYS LEVEL
	$sysSiteTitle = "Raweryk - najlepszy serwer Metin2 w Polsce!";
	$sysNavIndex = "Strona Główna";
	$sysNavRegister = "Rejestracja";
	$sysNavDownload = "Pobierz";
	$sysServerHello ="Witaj na serwerze";
	$sysServerDesc ="Raweryk to najlepszy serwer Metin2 w Polsce, a może i w Europie!";
	$sysNavSeparate = " ";

//	CORE LEVEL
	$coreServerHello = "Witaj na serwerze";
	$coreServerName = "Raweryk";
	$coreServerDesc = "coreServerDesc"; //DEL
	$coreButtonDesc = "Załóż konto";
	$coreAssist = "Masz już konto?";
	$coreAssistLink= "Kliknij tutaj, aby pobrać";

//	USER LEVEL
	$userServerName = "userServerName"; //DEL
	$userNavBoard = "Forum";
	$userNavFacebook = "Facebook";
	$userNavDiscord = "Discord";
	
//	URI LEVEL
	$uriBoardURI = "#uriBoardURI";
	$uriDiscordURI = "#uriDiscordURI";
	$uriFacebookURI = "#uriFacebookURI";

// TIMER LEVEL
	//$timerSay = null;
?>