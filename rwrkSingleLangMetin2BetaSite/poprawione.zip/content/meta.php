<?php
	$metaTitle = "metaTitle";
	$metaDescription = "metaDescription";
	$metaKeywords = "metaKeywords";
	$metaRobots = "index, nofollow"; //OSTROŻNIE
?>
